
import UIKit

protocol customDelegate {
    func valueSet(update : String)
}

class SeconVC: UIViewController {

    var delegate : customDelegate! = nil
    
    @IBOutlet weak var txtName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func didTapPop(_ sender: UIButton) {
        if (txtName.text?.characters.count)! > 0 {
            
            delegate.valueSet(update: txtName.text!)
           dismiss(animated: true, completion: nil)
         
            
        }else{
            let alertC = UIAlertController(title: "Demo", message: "Please enter text in textField.", preferredStyle: UIAlertControllerStyle.alert)
            let action = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
            alertC.addAction(action)
            self.present(alertC, animated: true, completion: nil)
        }
       
    }
    

}
