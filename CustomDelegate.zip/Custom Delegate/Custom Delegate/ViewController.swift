
import UIKit

class ViewController: UIViewController,customDelegate {

    @IBOutlet weak var lblName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func valueSet(update : String){
        self.lblName.text = update
    }
    
    @IBAction func didTapPush(_ sender: UIButton) {
        
       self.performSegue(withIdentifier: "Second", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Second" {
            let destination = segue.destination as! SeconVC
            destination.delegate = self
        }
    }
    
}

